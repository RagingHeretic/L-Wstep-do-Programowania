print("="*20,"Początek danych","="*20)
with open("pliki/tekst.txt", "r", encoding="utf-8") as op:
    dane = op.read()
print(dane)
# print(dane.rstrip())
print("="*20,"Koniec danych","="*20)
