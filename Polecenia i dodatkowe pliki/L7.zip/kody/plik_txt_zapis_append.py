with open("zapis/zapis.txt", "a", encoding="utf-8") as op:
    op.write(" oraz rybki.")
