with open("pliki/tekst.txt", encoding="utf-8") as op:
    lista_wierszy = op.readlines()

for wiersz in lista_wierszy:
    print(f"wiersz: {wiersz}")
