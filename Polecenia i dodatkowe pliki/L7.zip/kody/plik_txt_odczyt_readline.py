op = open("pliki/tekst.txt", "r", encoding="utf-8")
while True:
    wiersz = op.readline()
    print(wiersz)
    if not wiersz:
        break
op.close()
