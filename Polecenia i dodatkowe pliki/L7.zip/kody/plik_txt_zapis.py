with open("zapis/zapis.txt", "w", encoding="utf-8") as op:
    op.write("Ala")
    op.write("ma")
    op.writelines(["kota", "i psa."])
    # op.write("Ala ")
    # op.write("ma ")
    # op.writelines(["kota ", "i psa."])

