import tempfile, os
napis = """Karolina poszła na zakupy, a później do kina.
Jeśli dobrze zrozumiałem Karola, to zapału do pracy on dziś nie ma."""
# tempfile.TemporaryFile(tryb)
# tempfile.TemporaryDirectory()
print(f"os.listdir(): {os.listdir()}")
# mode=w+b, buffering=-1, encoding=None, newline=None
# w+ odczyt i zapis
# w+b odczyt i zapis bajtów
with tempfile.TemporaryFile("w+") as temp_op:
    temp_op.write(napis)
    print("type(temp_op):", type(temp_op))
    temp_op.seek(0)
    print(f"temp_op.read(): {temp_op.read()}")

# błąd
# print(temp_op.read())



