class Moj_Men_Kont():
    def __enter__(self):
        print("Metoda __enter__()")
        return self

    def __exit__(self, ex_type, ex_value, ex_traceback):
        print("Metoda __exit__()")

with Moj_Men_Kont():
    pass

