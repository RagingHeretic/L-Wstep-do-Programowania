# https://docs.python.org/3/library/functions.html#open
# wczytanie pierwszych 40 znaków
with open("pliki/obraz.jpg", "rb") as op:
    print("op.read()[:40]:", op.read()[:40])

# błąd, plik nie jest tekstowy tylko binarny
# with open("pliki/obraz.jpg", "r") as op:
#     print("op.read()[:40]:", op.read()[:40])

# błąd, plik nie jest tekstowy tylko binarny
# with open("pliki/obraz.jpg", "r") as op:
#     print("op.read():", op.read())

# wczytanie całego pliku
# with open("pliki/obraz.jpg", "rb") as op:
#     print("op.read():", op.read())