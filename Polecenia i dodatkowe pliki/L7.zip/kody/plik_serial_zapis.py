# serializacja łańcucha znakowego do pliku, pośrednia i bezpośrednia
# oraz zapis łańcucha znakowego do pliku tekstowego
import pickle
napis = """Karolina poszła na zakupy, a później do kina.
Jeśli dobrze zrozumiałem Karola, to zapału do pracy on dziś nie ma."""

# serializacja pośrednia
# najpierw serializowany jest napis,
# następnie zserializowany napis, jest zapisywany do pliku binarnego
napis_zserializowany = pickle.dumps(napis)
print(f"napis_zserializowany:", napis_zserializowany)
with open("zapis/napis_serial_posr.srl", "wb") as op:
     op.write(napis_zserializowany)

# serializacja bezpośrednia do pliku
with open("zapis/napis_serial_bezposr.srl", "wb") as op:
     pickle.dump(napis, op)

# zapis napisu do pliku tekstowego
with open("zapis/napis_txt.txt", "wt") as op:
     op.write(napis)
