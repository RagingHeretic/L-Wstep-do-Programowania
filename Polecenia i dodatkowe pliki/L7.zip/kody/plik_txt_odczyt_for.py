print("="*20,"Początek danych","="*20)
with open("pliki/tekst.txt", "r", encoding="utf-8") as op:
    for wiersz in op:
        print(f"wiersz: {wiersz}")
        # print(f"wiersz.strip(): {wiersz.strip()}")
print("="*20,"Koniec danych","="*20)