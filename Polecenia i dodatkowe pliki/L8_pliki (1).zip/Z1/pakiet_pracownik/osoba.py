class Osoba:
    """
    klasa Osoba jest szablonem dotyczącym osoby
    zawiera pola:
      imie z imieniem osoby
      nazwisko z nazwiskiem osoby
      nrTel z telefonem osoby
    zawiera metodę wypiszOsobe() wypisującą imie, nazwisko oraz nrTel osoby – jeśli zostały podane
    """


    def __init__(self, imie=None, nazwisko=None, nrTel=None):
        """
        Konstruktor klasy Osoba
        jest on automatycznie wywoływany przy tworzeniu obiektu klasy
        """
        self.imie = imie
        self.nazwisko = nazwisko
        self.nrTel = nrTel

    def wypisz(self):
        if self.imie or self.nazwisko or self.nrTel:
            print("\tOto dane osoby:")
            if self.imie:
                print(f"\t\tImię: {self.imie}")
            if self.nazwisko:
                print(f"\t\tNazwisko: {self.nazwisko}")
            if self.nrTel:
                print(f"\t\tNr telefonu: {self.nrTel}")
            print()
        else:
            print("\tNie podano żadnych danych o osobie.")