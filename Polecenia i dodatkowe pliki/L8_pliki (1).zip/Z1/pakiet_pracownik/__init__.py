from pakiet_pracownik.osoba import Osoba
from pakiet_pracownik.pracownik import Pracownik