from pakiet_pracownik.osoba import Osoba

class Pracownik(Osoba):
    def __init__(self, imie=None, nazwisko=None, nrTel=None, mscZatr=None, stanowisko=None):
        super().__init__(imie, nazwisko, nrTel)
        self.mscZatr = mscZatr
        self.stanowisko = stanowisko

    def wypisz(self):
        super().wypisz()
        if self.mscZatr or self.stanowisko:
            print("\tOto dane dotyczące zatrudnienia:")
            if self.mscZatr:
                print(f"\t\tMiejsce zatrudnienia: {self.mscZatr}")
            if self.stanowisko:
                print(f"\t\tStanowisko: {self.stanowisko}")
            print()
        else:
            print("\tNie podano żadnych danych o zatrudnieniu.\n\n")
