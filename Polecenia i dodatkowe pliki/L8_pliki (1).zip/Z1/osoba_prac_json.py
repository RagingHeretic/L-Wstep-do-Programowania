import pakiet_pracownik

o = pakiet_pracownik.Osoba("Karol", "Mackiewicz", "600 100 300")
o.wypisz()


p = pakiet_pracownik.Pracownik("Anna", "Kowalska", "603 500 400","Kowal Inwest","specjalista ds. kadr")
p.wypisz()
