from openpyxl import Workbook

skoroszyt = Workbook()
arkusz = skoroszyt.active

arkusz["A1"] = "zadanie"
arkusz["B1"] = "opis"

arkusz["A2"] = "kupić pieczywo"
arkusz["B2"] = "kupić 2 bochenki chleba i 4 duże bułki"

arkusz["A3"] = "wysłać odpowiedź"
arkusz["B3"] = "odpisać Jankowi na maila"

skoroszyt.save(filename="pliki_xlsx/lista_zadan.xlsx")