from openpyxl import load_workbook
skoroszyt = load_workbook(filename="pliki_xlsx/lista_zadan.xlsx")
print(f"skoroszyt.sheetnames: {skoroszyt.sheetnames}")
arkusz = skoroszyt.active

print()
# źródło danych w arkuszu
print(f"arkusz.dimensions: {arkusz.dimensions}")


print()
for wiersz in arkusz.rows:
    print(f"wiersz: {wiersz}")

print()
# wyświetlenie wartości wszystkich wierszy
for wiersz in arkusz.rows:
    print(f"{wiersz[0].value:20} {wiersz[1].value:40}")

print()
# wyświetlenie wartości komórek A1-A3 oraz B1-B3
for i in range(1, 4):
    komorkaA = "A"+str(i)
    komorkaB = "B" + str(i)
    print(f"{arkusz[komorkaA].value:20} {arkusz[komorkaB].value:40}")
    # alternatywny sposób wyświetlenia zawartości komórek
    # print(f"{arkusz.cell(row=i, column=1).value:20} {arkusz.cell(row=i, column=2).value:40}")

print()
# zakres danych
zakres_danych = arkusz["A1:B3"]
print(f"zakres_danych: {zakres_danych}")
# wyśw. wartości komórek A3 i B3
print(f"{zakres_danych[2][0].value:20} {zakres_danych[2][1].value:40}")


